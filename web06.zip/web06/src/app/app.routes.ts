import { Routes } from '@angular/router';
import { Contato } from './contato/contato';
import { Vitrine } from './vitrine/vitrine';
import { Cesta } from './cesta/cesta';
import { Detalhe } from './detalhe/detalhe';

export const routes: Routes = [
    {path:"contato", component:Contato},
    {path:"fale-conosco", component:Contato},
    {path:"", component:Vitrine},
    {path:"vitrine", component:Vitrine},
    {path:"cesta", component:Cesta},
    {path:"detalhe", component:Detalhe}
];
